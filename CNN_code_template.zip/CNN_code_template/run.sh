python main.py -mode=train -num_epoches=10 \
-learning_rate=0.01 -dropout=0.2 -batch_size=100 -rotation=15

python main.py -mode=train -num_epoches=10 \
-learning_rate=0.001 -dropout=0.2 -batch_size=100 -rotation=15

python main.py -mode=train -num_epoches=10 \
-learning_rate=0.004 -dropout=0.2 -batch_size=100 -rotation=15

python main.py -mode=train -num_epoches=10 \
-learning_rate=0.01 -dropout=0.5 -batch_size=100 -rotation=15
